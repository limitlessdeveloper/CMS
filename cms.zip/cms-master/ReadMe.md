# UTOPIA - A Basic Simple Content Management System [FINAL YEAR PROJECT]

Build Status : WIP 

## Features
- Blog like feel, interface
- Rich admin panel
- Fully customizable
- Rich design and responsive
- Running on Bootstrap 3.4 [WIP for v4.0]
- Rich bootstrap themes [WIP]
- Real time notifications
- Encrypted 


## Why you might need it 
I really don't know why you need it , may be you are looking for some code for inspiration or you are just too lazy to make your project your own.

Who am'i to judge 😂

### IMPORTANT - This CMS is not for WEB as i did't concern more on security , probably will update the code as i get time for now just use it as a project example.

## Licence

This Software is distributed under [MIT](https://opensource.org/licenses/MIT) license. Please read LICENSE for information on the software availability and distribution.

## Installation & loading
Utopia is avaliable here on github clone or download [zip](https://codeload.github.com/TheFrustratedDeveloper/cms/zip/master).

## Required 
- [Composer](https://getcomposer.org/)
- [PHPMAILER/PHPMAILER](https://github.com/PHPMailer/PHPMailer)
- [PUSHER Credentials](https://pusher.com/)
- [Toastr.js](https://cdnjs.com/libraries/toastr.js/latest)

### NOTE: Clean SQL file is attached with structure. Default Login is root as username and toor as password.

## Security
Please disclose any vulnerabilities found responsibly - report any security problems found to the maintainers privately.
[theFrustratedDeveloper](https://github.com/TheFrustratedDeveloper/)

## Contributing
Please submit bug reports, suggestions and pull requests to the [GitHub issue tracker](https://github.com/TheFrustratedDeveloper/cms/issues).

If you found a mistake in the docs, or want to add something, go ahead and amend the wiki - anyone can edit it.

## Credits 
PHPMAILER , SUMMERNOTE , Pusher , Toastr.js

## Contacts 
- Facebook user profile : [https://www.facebook.com/dhruvsaxena1998](https://www.facebook.com/dhruvsaxena1998)

