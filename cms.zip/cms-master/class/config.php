<?php 
    Class config{
       const SMTP_HOST = 'smtp.mailtrap.io';
       const SMTP_PORT = 2525;
       const SMTP_USER = '3f56528acdba21';
       const SMTP_PASSWORD = 'f40a4a4a3943e4';
    }
?>